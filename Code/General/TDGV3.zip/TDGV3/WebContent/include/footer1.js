var str='';
str+= '<!-- Footer Starts -->';
str+= '<footer class="footerCont clearfix">'
str+= '	<article class="content"><section class="copy fLft">2013-14 &copy; Seshadri</section><section class="fRght"><a href="#" class="copy">Back to top</a></section></article>'
str+= '</footer>'
str+= '<!-- Footer Ends -->';
document.write(str); 