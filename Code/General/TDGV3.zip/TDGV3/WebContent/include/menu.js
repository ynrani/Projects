var topNav='';
topNav+=' <section>';
topNav+='<nav class="mainTabCtrl clearfix">';
topNav+='	<ul>';
topNav+='		<li id="Provider_Search"><a href="./testdaUser">Provider Search</a><span>Provider Search </span></li>';
topNav+='		<li id="Subscriber_Search"><a href="./testdaSubscUser">Subscriber Search</a><span>Subscriber Search</span></li>';
topNav+='		<li id="Claim_Search"><a href="./testdaClaimUser">Claim Search</a><span>Claim Search</span></li>';
topNav+='		<li id="Non_Standard_Search"><a href="./testdaNonStand">Non Standard Search</a><span>Non Standard Search</span></li>';
topNav+='	</ul>';
/*topNav+='	<hr align="center" width="63.45%">';*/
topNav+='</nav>';
topNav+='   </section>';
document.write(topNav);