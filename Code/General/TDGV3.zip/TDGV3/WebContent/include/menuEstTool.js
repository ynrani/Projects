var topNav='';
topNav+='<nav class="mainTabCtrl clearfix">';
topNav+='	<ul>';
topNav+='		<li id="tdmEstimationTool"><a href="./tdmEstimationTool">TDM Estimation Tool</a><span>TDM Estimation Tool</span></li>';
topNav+='		<li id="tdpEstimationTool"><a href="./tdpEstimationTool">TDP Estimation Tool</a><span>TDP Estimation Tool</span></li>';
topNav+='	</ul>';
topNav+='</nav>';
document.write(topNav);