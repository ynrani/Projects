var topNav='';
topNav+='<nav class="mainTabCtrl clearfix">';
topNav+='	<ul>';
topNav+='		<li id="Provider_Rev"><a href="./myReservationProv">Provider Reservations</a><span>Provider Reservations </span></li>';
topNav+='		<li id="Subscriber_Rev"><a href="./myReservationSubc">Subscriber Reservations</a><span>Subscriber Reservations</span></li>';
topNav+='		<li id="Claim_Rev"><a href="./myReservationClaim">Claim Reservations</a><span>Claim Reservations</span></li>';
topNav+='	</ul>';
topNav+='</nav>';
document.write(topNav);