/*
 * Object Name : TdgProfileDAOImpl.java
 * Modification Block
 * ------------------------------------------------------------------
 * S.No.	Name 			Date			Bug_Fix_No			Desc
 * ------------------------------------------------------------------
 * 	1.	  vkrish14		1:45:26 PM				Created
 * ------------------------------------------------------------------
 * Copyrights: 2015 Capgemini.com
 */
package com.tesda.dao.impl;

import org.springframework.stereotype.Component;

import com.tesda.dao.TdgProfileDAO;
import com.tesda.model.DO.TdgProfileDO;

/**
 * @author vkrish14
 *
 */
@Component("tdgProfileDAO")
public class TdgProfileDAOImpl implements TdgProfileDAO{

	@Override
	public String saveProfileData(TdgProfileDO tdgProfileDO){
		// TODO Auto-generated method stub
		return null;
	}
}
