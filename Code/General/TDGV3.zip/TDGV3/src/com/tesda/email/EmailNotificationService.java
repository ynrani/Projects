/*
 * Object Name : EmailNotificationService.java
 * Modification Block
 * ---------------------------------------------------------------------
 * S.No.	Name 			Date			Bug_Fix_No			Desc
 * ---------------------------------------------------------------------
 * 	1.	  vkrish14		Jun 15, 2015			NA             Created
 * ---------------------------------------------------------------------
 * Copyrights: 2015 Capgemini.com
 */
package com.tesda.email;

import com.tesda.model.DTO.ForgotPassword;

public interface EmailNotificationService{
	public void sendEmailNotification(ForgotPassword forgotPasswordDTO);
}
