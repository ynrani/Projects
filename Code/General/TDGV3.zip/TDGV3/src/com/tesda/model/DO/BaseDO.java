/*
 * Object Name : BaseDO.java
 * Modification Block
 * ---------------------------------------------------------------------
 * S.No.	Name 			Date			Bug_Fix_No			Desc
 * ---------------------------------------------------------------------
 * 	1.	  vkrish14		Jun 15, 2015			NA             Created
 * ---------------------------------------------------------------------
 * Copyrights: 2015 Capgemini.com
 */
package com.tesda.model.DO;

import java.io.Serializable;

public abstract class BaseDO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
