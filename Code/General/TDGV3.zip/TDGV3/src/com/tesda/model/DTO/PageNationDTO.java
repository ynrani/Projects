/*
 * Object Name : PageNationDTO.java
 * Modification Block
 * ---------------------------------------------------------------------
 * S.No.	Name 			Date			Bug_Fix_No			Desc
 * ---------------------------------------------------------------------
 * 	1.	  vkrish14		Jun 15, 2015			NA             Created
 * ---------------------------------------------------------------------
 * Copyrights: 2015 Capgemini.com
 */
package com.tesda.model.DTO;

public class PageNationDTO{
	private String name;
	private String position;
	private String office;
	private String phone;
	private String start_date;
	private String salary;

	public String getName(){
		return name;
	}

	public void setName(String name){
		this.name = name;
	}

	public String getPosition(){
		return position;
	}

	public void setPosition(String position){
		this.position = position;
	}

	public String getOffice(){
		return office;
	}

	public void setOffice(String office){
		this.office = office;
	}

	public String getPhone(){
		return phone;
	}

	public void setPhone(String phone){
		this.phone = phone;
	}

	public String getStart_date(){
		return start_date;
	}

	public void setStart_date(String start_date){
		this.start_date = start_date;
	}

	public String getSalary(){
		return salary;
	}

	public void setSalary(String salary){
		this.salary = salary;
	}
}
