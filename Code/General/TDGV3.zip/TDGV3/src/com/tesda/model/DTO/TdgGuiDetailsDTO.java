/*
 * Object Name : TdgGuiDetailsDTO.java
 * Modification Block
 * ---------------------------------------------------------------------
 * S.No.	Name 			Date			Bug_Fix_No			Desc
 * ---------------------------------------------------------------------
 * 	1.	  vkrish14		Jun 15, 2015			NA             Created
 * ---------------------------------------------------------------------
 * Copyrights: 2015 Capgemini.com
 */
package com.tesda.model.DTO;

public class TdgGuiDetailsDTO extends AbstractBaseDTO{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private long reqguiid;
	private String columnValues;
	private String columnLabel;
	private String columnType;
	private String columnname;
	private TdgSchemaDTO tdgSchemaDTO;

	public long getReqguiid(){
		return reqguiid;
	}

	public void setReqguiid(long reqguiid){
		this.reqguiid = reqguiid;
	}

	public String getColumnValues(){
		return columnValues;
	}

	public void setColumnValues(String columnValues){
		this.columnValues = columnValues;
	}

	public String getColumnLabel(){
		return columnLabel;
	}

	public void setColumnLabel(String columnLabel){
		this.columnLabel = columnLabel;
	}

	public String getColumnType(){
		return columnType;
	}

	public void setColumnType(String columnType){
		this.columnType = columnType;
	}

	public String getColumnname(){
		return columnname;
	}

	public void setColumnname(String columnname){
		this.columnname = columnname;
	}

	public TdgSchemaDTO getTdgSchemaDTO(){
		return tdgSchemaDTO;
	}

	public void setTdgSchemaDTO(TdgSchemaDTO tdgSchemaDO){
		this.tdgSchemaDTO = tdgSchemaDO;
	}
}
