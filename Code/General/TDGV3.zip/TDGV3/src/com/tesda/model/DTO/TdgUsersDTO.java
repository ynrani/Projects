/*
 * Object Name : TdgUsersDTO.java
 * Modification Block
 * ---------------------------------------------------------------------
 * S.No.	Name 			Date			Bug_Fix_No			Desc
 * ---------------------------------------------------------------------
 * 	1.	  vkrish14		Jun 15, 2015			NA             Created
 * ---------------------------------------------------------------------
 * Copyrights: 2015 Capgemini.com
 */
package com.tesda.model.DTO;

import org.springframework.web.multipart.MultipartFile;

public class TdgUsersDTO extends AbstractBaseDTO{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String userid;
	private String url;
	private String username;
	private String password;
	private transient MultipartFile multipartFiles;

	public String getUserid(){
		return userid;
	}

	public void setUserid(String userid){
		this.userid = userid;
	}

	public String getUrl(){
		return url;
	}

	public void setUrl(String url){
		this.url = url;
	}

	public String getUsername(){
		return username;
	}

	public void setUsername(String userName){
		this.username = userName;
	}

	public String getPassword(){
		return password;
	}

	public void setPassword(String password){
		this.password = password;
	}

	public MultipartFile getMultipartFiles(){
		return multipartFiles;
	}

	public void setMultipartFiles(MultipartFile multipartFiles){
		this.multipartFiles = multipartFiles;
	}
}
