/*
 * Object Name : TdgMetricsServiceImpl.java
 * Modification Block
 * ------------------------------------------------------------------
 * S.No.	Name 			Date			Bug_Fix_No			Desc
 * ------------------------------------------------------------------
 * 	1.	  vkrish14		4:13:34 PM				Created
 * ------------------------------------------------------------------
 * Copyrights: 2015 Capgemini.com
 */
package com.tesda.service.impl;

import org.springframework.stereotype.Component;

import com.tesda.service.TdgMetricsService;

/**
 * @author vkrish14
 *
 */
@Component("tdgMetricsService")
public class TdgMetricsServiceImpl implements TdgMetricsService{
}
